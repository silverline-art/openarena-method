"""EXMO Animal Gait Analysis Pipeline - Production-Grade System"""
__version__ = "1.0.0"
